package br.edu.fatecpg.atividade7heranca.model;

public interface OperacaoMatematica {
		public double somar(double a, double b);
		public double subtrair(double a, double b);
		public double multiplicarr(double a, double b);
		public double dividir(double a, double b);
		
}
