package br.edu.fatecpg.atividade7heranca.model;

public interface pagamento {
	
	public double calcularPagamento();
	
	public String emitirRecibo();
}
